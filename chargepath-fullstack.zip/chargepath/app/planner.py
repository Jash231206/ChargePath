"""Pure planning engine: range estimate, route alternatives, charging stops, scoring, drive events.
The score() weights are the hook where an ML model or LLM re-ranker can be plugged in."""
import math
W = {"fast": (1.2, 0.0, .008), "bal": (1.0, .035, .035), "cheap": (.6, .11, .1)}  # time, cost-in-stop-choice, cost-in-route-score
BASE = [("Fastest highway", 0, 1.08, 88), ("Balanced", .04, 1.14, 75), ("Eco scenic", -.04, 1.2, 62)]
WAIT = lambda s: 15 if s["free"] == 0 else 4 if s["free"] == 1 else 0

def charge_minutes(a, b, P, cap):  # fast to 80%, tapered above
    lim, h = .8*cap, 0
    if a < lim: h += (min(b, lim)-a)/(P*.85)
    if b > lim: h += (b-max(a, lim))/(P*.35)
    return h*60

def range_estimate(veh, soc, min_soc, cond=1.0, soh=100):
    cap = veh["cap"]*soh/100; c = veh["eff"]/1000*cond
    return {"usable_kwh": round(cap, 1), "range_km": round(cap*soc/100/c), "range_above_reserve_km": round(cap*max(0, soc-min_soc)/100/c), "full_range_km": round(cap/c)}

def plan_routes(a, b, veh, stations, soc, min_soc=10, tgt=80, pref="bal", cond=1.0, soh=100, net="any"):
    dx, dy = b["x"]-a["x"], b["y"]-a["y"]; d = math.hypot(dx, dy); nx, ny = -dy/d, dx/d
    routes = []
    for k, (name, o, f, sp) in enumerate(BASE):
        m = ((a["x"]+b["x"])/2+nx*o*d, (a["y"]+b["y"])/2+ny*o*d)
        routes.append(_plan(name, k, f, sp, [(a["x"], a["y"]), m, (b["x"], b["y"])], veh, stations, soc, min_soc, tgt, pref, cond, soh, net))
    best = min(range(3), key=lambda i: routes[i]["score"])
    for i, r in enumerate(routes): r["recommended"] = i == best
    return routes

def _plan(name, k, f, sp, pts, veh, stations, soc, min_soc, tgt, pref, cond, soh, net):
    cap = veh["cap"]*soh/100; wt, wc, wm = W[pref]; segs, acc = [], 0
    for i in range(2):
        (x1, y1), (x2, y2) = pts[i], pts[i+1]; l = math.hypot(x2-x1, y2-y1); segs.append((x1, y1, x2, y2, l, acc)); acc += l
    dist = acc*f; cons = veh["eff"]/1000*(.7+.3*(sp/70)**2)*cond; on, nearby = [], []
    for st in stations:
        best = None
        for x1, y1, x2, y2, l, s0 in segs:
            t = max(0, min(1, ((st["x"]-x1)*(x2-x1)+(st["y"]-y1)*(y2-y1))/(l*l)))
            dd = math.hypot(st["x"]-(x1+t*(x2-x1)), st["y"]-(y1+t*(y2-y1)))
            if best is None or dd < best[0]: best = (dd, (s0+t*l)*f)
        if best[0] <= 28:
            nearby.append(st["id"])
            if st["status"] == "online" and veh["cn"] in st["conn"] and (net == "any" or st["net"] == net): on.append((best[1], best[0], st))
    on.sort(key=lambda t: t[0])
    pos, e, res, stops, tt, cost, ok, min_s, alerts = 0, cap*soc/100, cap*min_soc/100, [], 0, 0, True, soc, []
    for _ in range(20):
        reach = (e-res)/cons
        if pos+reach >= dist: break
        cs = [c for c in on if pos+5 < c[0] <= pos+reach]
        if not cs:
            ok = False; alerts.append({"level": "danger", "msg": f"No compatible charger within range after {round(pos)} km. Raise starting charge, lower the reserve, change network, or pick another route."}); break
        rr = (cap*tgt/100-res)/cons
        fz = [c for c in cs if dist-c[0] <= rr or any(y[0] > c[0]+5 and y[0]-c[0] <= rr for y in on)]
        def score(c): P = min(c[2]["kw"], veh["kw"]); return (c[0]-pos)-wt*(c[1]*2.4+WAIT(c[2])+25/(P*.8)*60)-wc*c[2]["price"]*25
        p_, off, st = max(fz or cs, key=score)
        ea, need, lim = e-(p_-pos)*cons, (dist-p_)*cons+res, cap*tgt/100
        to = need*1.04 if need*1.04 <= lim else lim
        if to < ea+1: to = min(cap*.95, ea+1)
        P = min(st["kw"], veh["kw"]); ch, w, det, c = charge_minutes(ea, to, P, cap), WAIT(st), off*2.4, (to-ea)*st["price"]
        stops.append({"station_id": st["id"], "name": st["name"], "network": st["net"], "at_km": round(p_), "detour_km": round(off, 1), "arrive_pct": round(ea/cap*100), "depart_pct": round(to/cap*100),
                      "energy_kwh": round(to-ea, 1), "power_kw": P, "charge_min": round(ch), "wait_min": w, "cost": round(c), "ports_free": st["free"], "ports": st["ports"]})
        tt += ch+w+det; cost += c; min_s = min(min_s, ea/cap*100); e = to; pos = p_
        if ea/cap*100 < 10: alerts.append({"level": "warning", "msg": f"Low arrival charge ({round(ea/cap*100)}%) at {st['name']}."})
        if st["free"] == 0: alerts.append({"level": "warning", "msg": f"{st['name']} shows no free ports; expect a queue of about 15 min."})
    fin = (e-(dist-pos)*cons)/cap*100
    if ok:
        min_s = min(min_s, fin)
        if fin < min_pct(min_soc): alerts.append({"level": "warning", "msg": "Arrival charge falls below your reserve."})
    drive = dist/sp*60; risk = "High" if (not ok or min_s < 8) else "Medium" if min_s < 15 else "Low"
    score = drive+tt+cost*wm+len(stops)*6+(0 if ok else 1e5)+(80 if risk == "High" else 20 if risk == "Medium" else 0)
    return {"name": name, "index": k, "feasible": ok, "distance_km": round(dist), "drive_min": round(drive), "charge_wait_min": round(tt), "total_min": round(drive+tt),
            "energy_kwh": round(dist*cons, 1), "consumption_wh_km": round(cons*1000), "cost": round(cost), "arrival_pct": round(fin) if ok else None, "min_pct": round(min_s) if ok else 0,
            "risk": risk, "stops": stops, "alerts": alerts, "nearby_station_ids": nearby, "path": [list(p) for p in pts], "score": round(score, 1)}

min_pct = lambda v: v

def drive_events(route):
    """Turn a plan into ordered notifications (approach, arrive, charged, low battery, arrival)."""
    ev = []
    for i, s in enumerate(route["stops"], 1):
        ev.append({"at_km": max(0, s["at_km"]-25), "type": "approaching", "msg": f"Charging stop {i} in 25 km: {s['name']} ({s['ports_free']}/{s['ports']} ports free)"})
        if s["arrive_pct"] < 15: ev.append({"at_km": max(0, s["at_km"]-10), "type": "low_battery", "msg": f"Low battery: about {s['arrive_pct']}% on arrival at stop {i}"})
        ev.append({"at_km": s["at_km"], "type": "arrived", "msg": f"Arrived at {s['name']} with {s['arrive_pct']}%. Charging to {s['depart_pct']}%, about {s['charge_min']} min."})
        ev.append({"at_km": s["at_km"], "type": "charged", "msg": f"Charging complete at {s['depart_pct']}%."})
    ev.append({"at_km": route["distance_km"], "type": "destination", "msg": "Arrived at destination" + (f" with {route['arrival_pct']}%" if route["feasible"] else " (plan not feasible)")})
    return sorted(ev, key=lambda e: e["at_km"])
