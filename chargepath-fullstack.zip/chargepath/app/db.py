"""SQLite storage (swap for Postgres in production). Thread-safe via one lock."""
import os, sqlite3, threading, random, hashlib, secrets
_lock = threading.RLock()
conn = sqlite3.connect(os.getenv("DB_PATH", "chargepath.db"), check_same_thread=False)
conn.row_factory = sqlite3.Row

def q(sql, args=(), one=False):
    with _lock:
        cur = conn.execute(sql, args); rows = cur.fetchall(); conn.commit()
        return (rows[0] if rows else None) if one else rows

def ins(sql, args=()):
    with _lock:
        cur = conn.execute(sql, args); conn.commit(); return cur.lastrowid

def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 120_000).hex()

def check_pw(pw, stored):
    return secrets.compare_digest(hash_pw(pw, stored.split("$")[0]), stored)

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE, pw TEXT, role TEXT DEFAULT 'user');
CREATE TABLE IF NOT EXISTS cities(id INTEGER PRIMARY KEY, name TEXT, x REAL, y REAL);
CREATE TABLE IF NOT EXISTS vehicles(id INTEGER PRIMARY KEY, user_id INTEGER, name TEXT, cap REAL, eff REAL, kw REAL, cn TEXT);
CREATE TABLE IF NOT EXISTS stations(id INTEGER PRIMARY KEY, name TEXT, x REAL, y REAL, net TEXT, kw REAL, ports INTEGER, free INTEGER, price REAL, conn TEXT, status TEXT DEFAULT 'online');
CREATE TABLE IF NOT EXISTS trips(id INTEGER PRIMARY KEY, user_id INTEGER, created TEXT DEFAULT CURRENT_TIMESTAMP, src TEXT, dst TEXT, vehicle TEXT, route TEXT, dist REAL, minutes REAL, kwh REAL, cost REAL, stops INTEGER, min_soc REAL, status TEXT DEFAULT 'planned', plan TEXT);
"""
CITIES = [("Pune",100,78),("Solapur",317,174),("Hubballi",233,429),("Hyderabad",590,205),("Kurnool",543,377),
          ("Vijayawada",820,301),("Anantapur",496,505),("Bengaluru",495,694),("Tirupati",689,621),("Chennai",779,682)]
PRESETS = [("Tata Tiago EV",24,120,25),("Tata Punch EV",35,140,50),("Tata Nexon EV",40.5,150,60),("Mahindra XUV400",39.4,150,50),("MG ZS EV",50.3,160,75)]

def init():
    with _lock:
        conn.executescript(SCHEMA)
        if not q("SELECT 1 FROM cities", one=True):
            for c in CITIES: ins("INSERT INTO cities(name,x,y) VALUES(?,?,?)", c)
            r, nets, i = random.Random(11), ["VoltGrid","ChargeNet","EcoPlug"], 0
            for a in range(len(CITIES)):
                for b in range(a+1, len(CITIES)):
                    A, B = CITIES[a], CITIES[b]; L = ((B[1]-A[1])**2 + (B[2]-A[2])**2) ** .5
                    if L > 520: continue
                    n = max(1, int(L // 80))
                    for k in range(1, n+1):
                        t = k/(n+1); x = A[1]+(B[1]-A[1])*t+(r.random()-.5)*16; y = A[2]+(B[2]-A[2])*t+(r.random()-.5)*16
                        near = min(CITIES, key=lambda c: (c[1]-x)**2 + (c[2]-y)**2)[0]; i += 1; p = 2 + int(r.random()*7)
                        ins("INSERT INTO stations(name,x,y,net,kw,ports,free,price,conn,status) VALUES(?,?,?,?,?,?,?,?,?,?)",
                            (f"{near} {nets[i%3]} {i}", x, y, nets[i%3], r.choice([30,60,60,120,150]), p, int(r.random()*(p+1)),
                             round(12+r.random()*10,1), "CCS2", "offline" if r.random() < .06 else "online"))
        email, pw = os.getenv("ADMIN_EMAIL","admin@chargepath.local"), os.getenv("ADMIN_PASSWORD","admin12345")
        if not q("SELECT 1 FROM users WHERE email=?", (email,), one=True):
            ins("INSERT INTO users(email,pw,role) VALUES(?,?,'admin')", (email, hash_pw(pw)))
