"""ChargePath API. Run: uvicorn app.main:app --reload   Docs: /docs"""
import os, json, time, random, asyncio
from typing import Optional, Literal
import jwt
from fastapi import FastAPI, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
from . import db, planner

SECRET = os.getenv("SECRET_KEY", "dev-secret-change-me")
app = FastAPI(title="ChargePath API", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "*").split(","), allow_methods=["*"], allow_headers=["*"])
db.init()
bearer = HTTPBearer(auto_error=False)

# ---------- auth ----------
def user(c: Optional[HTTPAuthorizationCredentials] = Depends(bearer)):
    try: p = jwt.decode(c.credentials, SECRET, algorithms=["HS256"])
    except Exception: raise HTTPException(401, "Missing or invalid token")
    u = db.q("SELECT id,email,role FROM users WHERE id=?", (int(p["sub"]),), one=True)
    if not u: raise HTTPException(401, "Unknown user")
    return dict(u)

def admin(u=Depends(user)):
    if u["role"] != "admin": raise HTTPException(403, "Admin only")
    return u

class Cred(BaseModel):
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$"); password: str = Field(min_length=8)

def tok(u): return {"token": jwt.encode({"sub": str(u["id"]), "exp": time.time()+7*86400}, SECRET, "HS256"), "role": u["role"]}

@app.post("/api/auth/register", status_code=201)
def register(c: Cred):
    if db.q("SELECT 1 FROM users WHERE email=?", (c.email.lower(),), one=True): raise HTTPException(409, "Email already registered")
    uid = db.ins("INSERT INTO users(email,pw) VALUES(?,?)", (c.email.lower(), db.hash_pw(c.password)))
    for n, cap, eff, kw in db.PRESETS[:3]: db.ins("INSERT INTO vehicles(user_id,name,cap,eff,kw,cn) VALUES(?,?,?,?,?,'CCS2')", (uid, n, cap, eff, kw))
    return tok({"id": uid, "role": "user"})

@app.post("/api/auth/login")
def login(c: Cred):
    u = db.q("SELECT * FROM users WHERE email=?", (c.email.lower(),), one=True)
    if not u or not db.check_pw(c.password, u["pw"]): raise HTTPException(401, "Invalid email or password")
    return tok(u)

@app.get("/api/health")
def health(): return {"ok": True, "stations": db.q("SELECT COUNT(*) n FROM stations", one=True)["n"]}

@app.get("/api/cities")
def cities(): return [dict(r) for r in db.q("SELECT * FROM cities")]

# ---------- vehicles ----------
class VehicleIn(BaseModel):
    name: str = Field(min_length=1, max_length=60); cap: float = Field(gt=5, lt=300); eff: float = Field(gt=50, lt=500)
    kw: float = Field(gt=1, lt=500); cn: Literal["CCS2", "CHAdeMO", "Type2"] = "CCS2"

@app.get("/api/vehicles/presets")
def presets(): return [dict(name=n, cap=c, eff=e, kw=k, cn="CCS2") for n, c, e, k in db.PRESETS]

@app.get("/api/vehicles")
def vehicles(u=Depends(user)): return [dict(r) for r in db.q("SELECT * FROM vehicles WHERE user_id=?", (u["id"],))]

@app.post("/api/vehicles", status_code=201)
def add_vehicle(v: VehicleIn, u=Depends(user)):
    return {"id": db.ins("INSERT INTO vehicles(user_id,name,cap,eff,kw,cn) VALUES(?,?,?,?,?,?)", (u["id"], v.name, v.cap, v.eff, v.kw, v.cn)), **v.model_dump()}

@app.delete("/api/vehicles/{vid}", status_code=204)
def del_vehicle(vid: int, u=Depends(user)): db.q("DELETE FROM vehicles WHERE id=? AND user_id=?", (vid, u["id"]))

# ---------- stations ----------
class StationIn(BaseModel):
    name: str; x: float; y: float; net: str = "ChargeNet"; kw: float = Field(gt=1); ports: int = Field(ge=1, le=40)
    price: float = Field(ge=0, le=100); conn: str = "CCS2"; free: Optional[int] = None; status: Literal["online", "offline"] = "online"

class StationPatch(BaseModel):
    kw: Optional[float] = None; ports: Optional[int] = None; free: Optional[int] = None; price: Optional[float] = None; status: Optional[Literal["online", "offline"]] = None

def st_row(r): d = dict(r); d["conn"] = d["conn"].split(","); return d

@app.get("/api/stations")
def stations(network: Optional[str] = None, connector: Optional[str] = None, status: Optional[str] = None, min_kw: float = 0):
    rows = [st_row(r) for r in db.q("SELECT * FROM stations")]
    return [s for s in rows if (not network or s["net"] == network) and (not connector or connector in s["conn"]) and (not status or s["status"] == status) and s["kw"] >= min_kw]

@app.post("/api/stations", status_code=201)
def add_station(s: StationIn, _=Depends(admin)):
    return {"id": db.ins("INSERT INTO stations(name,x,y,net,kw,ports,free,price,conn,status) VALUES(?,?,?,?,?,?,?,?,?,?)", (s.name, s.x, s.y, s.net, s.kw, s.ports, s.ports if s.free is None else min(s.free, s.ports), s.price, s.conn, s.status))}

@app.patch("/api/stations/{sid}")
def patch_station(sid: int, p: StationPatch, _=Depends(admin)):
    cur = db.q("SELECT * FROM stations WHERE id=?", (sid,), one=True)
    if not cur: raise HTTPException(404, "Station not found")
    d = {**dict(cur), **p.model_dump(exclude_none=True)}; d["free"] = max(0, min(d["free"], d["ports"]))
    db.q("UPDATE stations SET kw=?,ports=?,free=?,price=?,status=? WHERE id=?", (d["kw"], d["ports"], d["free"], d["price"], d["status"], sid)); return d

@app.delete("/api/stations/{sid}", status_code=204)
def del_station(sid: int, _=Depends(admin)): db.q("DELETE FROM stations WHERE id=?", (sid,))

# Provider adapter: replace with OCPI / OCPP / Open Charge Map / OEM telematics ingestion.
class SimulatedProvider:
    name = "simulated"
    def refresh(self):
        n = 0
        for s in db.q("SELECT id,ports,free FROM stations WHERE status='online'"):
            if random.random() < .3: db.q("UPDATE stations SET free=? WHERE id=?", (max(0, min(s["ports"], s["free"]+random.choice([-1, 1]))), s["id"])); n += 1
        return n
provider = SimulatedProvider()

@app.post("/api/admin/feed/refresh")
def refresh(_=Depends(admin)): return {"provider": provider.name, "updated": provider.refresh()}

# ---------- planning ----------
class PlanIn(BaseModel):
    src: str; dst: str; vehicle_id: Optional[int] = None; vehicle: Optional[VehicleIn] = None
    soc: float = Field(80, ge=1, le=100); min_soc: float = Field(10, ge=0, le=50); target_soc: float = Field(80, ge=50, le=100)
    pref: Literal["fast", "bal", "cheap"] = "bal"; cond: float = Field(1.0, ge=.8, le=1.6); soh: float = Field(100, ge=50, le=100); network: str = "any"

def run_plan(p: PlanIn, u):
    cs = {c["name"]: dict(c) for c in db.q("SELECT * FROM cities")}
    if p.src not in cs or p.dst not in cs: raise HTTPException(422, "Unknown city")
    if p.src == p.dst: raise HTTPException(422, "Source and destination must differ")
    if p.vehicle_id:
        v = db.q("SELECT * FROM vehicles WHERE id=? AND user_id=?", (p.vehicle_id, u["id"]), one=True)
        if not v: raise HTTPException(404, "Vehicle not found")
        v = dict(v)
    elif p.vehicle: v = p.vehicle.model_dump()
    else: raise HTTPException(422, "Provide vehicle_id or vehicle")
    sts = [st_row(r) for r in db.q("SELECT * FROM stations")]
    return v, planner.plan_routes(cs[p.src], cs[p.dst], v, sts, p.soc, p.min_soc, p.target_soc, p.pref, p.cond, p.soh, p.network)

@app.post("/api/plan")
def plan(p: PlanIn, u=Depends(user)):
    v, routes = run_plan(p, u)
    return {"range": planner.range_estimate(v, p.soc, p.min_soc, p.cond, p.soh), "routes": routes}

# ---------- trips ----------
class TripIn(PlanIn): route_index: int = Field(0, ge=0, le=2)

@app.post("/api/trips", status_code=201)
def save_trip(t: TripIn, u=Depends(user)):  # re-plans server-side; never trusts client-supplied results
    v, routes = run_plan(t, u); r = routes[t.route_index]
    return {"id": db.ins("INSERT INTO trips(user_id,src,dst,vehicle,route,dist,minutes,kwh,cost,stops,min_soc,plan) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (u["id"], t.src, t.dst, v["name"], r["name"], r["distance_km"], r["total_min"], r["energy_kwh"], r["cost"], len(r["stops"]), r["min_pct"], json.dumps(r)))}

@app.get("/api/trips")
def trips(u=Depends(user)): return [{k: v for k, v in dict(r).items() if k != "plan"} for r in db.q("SELECT * FROM trips WHERE user_id=? ORDER BY id DESC", (u["id"],))]

def own_trip(tid, u):
    r = db.q("SELECT * FROM trips WHERE id=? AND user_id=?", (tid, u["id"]), one=True)
    if not r: raise HTTPException(404, "Trip not found")
    return r

@app.get("/api/trips/{tid}")
def trip(tid: int, u=Depends(user)): r = dict(own_trip(tid, u)); r["plan"] = json.loads(r["plan"]); return r

@app.delete("/api/trips/{tid}", status_code=204)
def del_trip(tid: int, u=Depends(user)): own_trip(tid, u); db.q("DELETE FROM trips WHERE id=?", (tid,))

@app.get("/api/trips/{tid}/events")
def events(tid: int, u=Depends(user)): return planner.drive_events(json.loads(own_trip(tid, u)["plan"]))

@app.post("/api/trips/{tid}/complete")
def complete(tid: int, u=Depends(user)): own_trip(tid, u); db.q("UPDATE trips SET status='completed' WHERE id=?", (tid,)); return {"status": "completed"}

# ---------- analytics & admin ----------
@app.get("/api/analytics")
def analytics(u=Depends(user)):
    a = db.q("SELECT COUNT(*) trips, COALESCE(SUM(dist),0) km, COALESCE(SUM(kwh),0) kwh, COALESCE(SUM(cost),0) spend, COALESCE(AVG(stops),0) avg_stops FROM trips WHERE user_id=?", (u["id"],), one=True)
    a = dict(a); a["wh_per_km"] = round(a["kwh"]*1000/a["km"]) if a["km"] else 0
    a["routes"] = {r["route"]: r["n"] for r in db.q("SELECT route, COUNT(*) n FROM trips WHERE user_id=? GROUP BY route", (u["id"],))}; return a

@app.get("/api/admin/dashboard")
def dashboard(_=Depends(admin)):
    s = db.q("SELECT COUNT(*) total, SUM(status='offline') offline, SUM(CASE WHEN status='online' THEN ports ELSE 0 END) ports, SUM(CASE WHEN status='online' THEN free ELSE 0 END) free FROM stations", one=True)
    s = dict(s); s["offline"] = s["offline"] or 0; s["utilization_pct"] = round((s["ports"]-s["free"])/s["ports"]*100) if s["ports"] else 0
    s["users"] = db.q("SELECT COUNT(*) n FROM users", one=True)["n"]; s["trips"] = db.q("SELECT COUNT(*) n FROM trips", one=True)["n"]
    s["by_network"] = {r["net"]: r["n"] for r in db.q("SELECT net, COUNT(*) n FROM stations GROUP BY net")}; return s

# ---------- live feed + static frontend (keep at end of file) ----------
@app.on_event("startup")
async def start_feed():
    if os.getenv("SIM_FEED", "1") == "1":
        async def loop():
            while True:
                await asyncio.sleep(8); await asyncio.to_thread(provider.refresh)
        asyncio.create_task(loop())

FRONT = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.isdir(FRONT): app.mount("/", StaticFiles(directory=FRONT, html=True), name="web")
