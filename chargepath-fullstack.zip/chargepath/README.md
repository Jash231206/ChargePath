# ChargePath backend

FastAPI + SQLite service behind the ChargePath planner. It owns vehicles, stations, route planning, trips, analytics and admin.

## Run
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload        # API on :8000, interactive docs at /docs
pytest                               # 4 test groups
docker build -t chargepath . && docker run -p 8000:8000 -v cp:/data chargepath
```
Environment: `SECRET_KEY` (set in production), `DB_PATH`, `CORS_ORIGINS` (comma list), `ADMIN_EMAIL`, `ADMIN_PASSWORD`.
Default dev admin: `admin@chargepath.local` / `admin12345`. **Change before deploying.**

## API
| Area | Endpoints |
|---|---|
| Auth | `POST /api/auth/register`, `POST /api/auth/login` (JWT bearer) |
| Reference | `GET /api/cities`, `GET /api/vehicles/presets`, `GET /api/health` |
| Vehicles | `GET/POST /api/vehicles`, `DELETE /api/vehicles/{id}` |
| Stations | `GET /api/stations?network=&connector=&status=&min_kw=`; admin: `POST`, `PATCH`, `DELETE /api/stations/{id}` |
| Planning | `POST /api/plan` returns range estimate plus 3 routes (stops, times, energy, cost, risk, alerts, recommended flag) |
| Trips | `POST /api/trips` (re-plans server-side and saves), `GET /api/trips`, `GET /api/trips/{id}`, `GET /api/trips/{id}/events` (approach, low-battery, arrival notifications), `POST /api/trips/{id}/complete`, `DELETE` |
| Insights | `GET /api/analytics`; admin: `GET /api/admin/dashboard`, `POST /api/admin/feed/refresh` |

Example:
```bash
TOKEN=$(curl -s localhost:8000/api/auth/register -H 'content-type: application/json' -d '{"email":"me@x.in","password":"password1"}' | python -c 'import sys,json;print(json.load(sys.stdin)["token"])')
curl -s localhost:8000/api/plan -H "authorization: Bearer $TOKEN" -H 'content-type: application/json' \
  -d '{"src":"Hyderabad","dst":"Bengaluru","vehicle":{"name":"Nexon","cap":40.5,"eff":150,"kw":60},"soc":90}'
```

## Structure
- `app/planner.py` pure planning engine (range, route alternatives, stop selection, scoring, drive events).
- `app/db.py` SQLite, schema, seed (South India cities, simulated stations, vehicle presets).
- `app/main.py` routes, auth, validation, provider adapter.

## Next steps
Postgres + migrations, refresh tokens, rate limiting, real routing (OSRM/Mapbox) replacing the straight-line route model, an OCPI/OCPP/Open Charge Map provider replacing `SimulatedProvider`, WebSocket push for live alerts, and an ML consumption model behind `planner.py`.

## Known limits
Routes are straight-line corridors on a simulated South India map, so city pairs without a charger corridor between them (for example Pune to Bengaluru) report as not reachable. Real road routing fixes this.
