import os, tempfile
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "t.db")
from fastapi.testclient import TestClient
from app.main import app
c = TestClient(app)
H = lambda t: {"Authorization": f"Bearer {t}"}

def reg(email="a@b.co"):
    return c.post("/api/auth/register", json={"email": email, "password": "password1"}).json()["token"]

def test_auth_and_health():
    assert c.get("/api/health").json()["stations"] > 20
    assert c.post("/api/auth/login", json={"email": "a@b.co", "password": "wrongpass1"}).status_code == 401
    t = reg(); assert c.post("/api/auth/register", json={"email": "a@b.co", "password": "password1"}).status_code == 409
    assert c.get("/api/vehicles").status_code == 401 and len(c.get("/api/vehicles", headers=H(t)).json()) == 3

def test_plan_three_routes_and_save():
    t = reg("p@b.co"); v = c.get("/api/vehicles", headers=H(t)).json()[2]
    r = c.post("/api/plan", headers=H(t), json={"src": "Hyderabad", "dst": "Bengaluru", "vehicle_id": v["id"], "soc": 90}).json()
    assert len(r["routes"]) == 3 and sum(x["recommended"] for x in r["routes"]) == 1 and r["range"]["range_km"] > 100
    assert any(x["feasible"] for x in r["routes"])
    tid = c.post("/api/trips", headers=H(t), json={"src": "Hyderabad", "dst": "Bengaluru", "vehicle_id": v["id"], "soc": 90}).json()["id"]
    ev = c.get(f"/api/trips/{tid}/events", headers=H(t)).json(); assert ev[-1]["type"] == "destination"
    assert c.get("/api/analytics", headers=H(t)).json()["trips"] == 1
    assert c.get(f"/api/trips/{tid}", headers=reg("o@b.co") and H(reg("o2@b.co"))).status_code == 404  # isolation

def test_validation():
    t = reg("v@b.co"); body = {"src": "Pune", "dst": "Pune", "vehicle": {"name": "x", "cap": 40, "eff": 150, "kw": 50}}
    assert c.post("/api/plan", headers=H(t), json=body).status_code == 422
    body["dst"] = "Atlantis"; assert c.post("/api/plan", headers=H(t), json=body).status_code == 422

def test_admin_permissions_and_station_crud():
    t = reg("u@b.co"); assert c.post("/api/admin/feed/refresh", headers=H(t)).status_code == 403
    a = c.post("/api/auth/login", json={"email": "admin@chargepath.local", "password": "admin12345"}).json()["token"]
    sid = c.post("/api/stations", headers=H(a), json={"name": "Test", "x": 1, "y": 1, "kw": 60, "ports": 4, "price": 15}).json()["id"]
    assert c.patch(f"/api/stations/{sid}", headers=H(a), json={"free": 99}).json()["free"] == 4
    assert c.get("/api/admin/dashboard", headers=H(a)).json()["total"] > 20
    assert c.delete(f"/api/stations/{sid}", headers=H(a)).status_code == 204

def test_frontend_served():
    assert "ChargePath" in c.get("/").text
    r = c.get("/app/"); assert r.status_code == 200 and "/api/plan" in r.text
    assert c.get("/api/health").status_code == 200
